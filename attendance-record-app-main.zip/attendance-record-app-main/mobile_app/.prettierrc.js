module.exports = {
  bracketSpacing: true,
  arrowParens: 'always',
  bracketSameLine: false,
  singleQuote: true,
  trailingComma: 'all',
  printWidth: 100,
  tabWidth: 2,
  useTabs: false,
};
