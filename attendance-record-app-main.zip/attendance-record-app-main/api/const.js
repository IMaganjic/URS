export const students = ["ikozul00", "mmucic00", "mbrigi00"];
